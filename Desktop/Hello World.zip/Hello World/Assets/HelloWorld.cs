﻿using UnityEngine;
using System.Collections;

public class HelloWorld : MonoBehaviour {

	// Use this for initialization
	void Start () {
		print ("hello world");
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
